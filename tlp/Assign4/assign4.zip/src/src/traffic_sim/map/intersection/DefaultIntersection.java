package traffic_sim.map.intersection;

public class DefaultIntersection extends Intersection{
    public DefaultIntersection(String name, float x, float y) {
        super(name, x, y);
    }
}
