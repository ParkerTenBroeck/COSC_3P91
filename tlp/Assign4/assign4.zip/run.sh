java -jar traffic_sim.jar $@
